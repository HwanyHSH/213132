package goott;

/*
 * [문제] 아래와 같은 내용을 콘솔 창에 출력해 보세요.
 * 		 단, 앞의 예제들에서 배울 내욜을 활용해서 사용해 보시기 바랍니다.
 * 
 * 	     이 름 : 한 성 환
 * 		 연락처 : 010-6607-6380
 * 		 이메일 : clxkdi123@naver.com
 * 		 주 소 : 경기도 이천시
 */

public class Basic_04 {

	public static void main(String[] args) {
		System.out.println("이\t름 : 한 성 환");
		
		System.out.print("연   락   처 : 010-6607-6380\n이   메   일 : ");
		
		System.out.print("clxkdi123@naver.com");
		
		System.out.println();
		
		System.out.print("주\t");
		
		System.out.println("소 : 경기도 이천시");
	}

}
